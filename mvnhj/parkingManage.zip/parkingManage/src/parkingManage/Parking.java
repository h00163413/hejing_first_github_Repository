package parkingManage;

import java.util.ArrayList;

public class Parking {
	private int parkingID = 0;
	private int fullNum = 0;
	private ArrayList<Car> carList=new ArrayList<Car>();
	static private ArrayList<Parking> ParkingList=new ArrayList<Parking>(); 
	
	public int getParckingID(){
		return parkingID;
	}
	
	public int getFullNum(){
		return fullNum;
	}
	
	public boolean setFullNum(int fullNum){
		this.fullNum = fullNum;
		return true;
	}
	
	public boolean addCar(Car car){
		return carList.add(car);
	}
	
	public boolean removeCar(Car car){
		return carList.remove(car);
	}
	
	static public ArrayList<Parking> geParkingList(){
		return ParkingList;
	}
}
