package parkingManage;
import java.util.*;

public class ParkingBoy {
	private int boyID = 0;
	private Manager manager;
	private ArrayList<Parking> regParkingsList=new ArrayList<Parking>();
	private ArrayList<Car> carList=new ArrayList<Car>();
	
	public int getBoyID(){
		return boyID;
	}
	
	public boolean setBoyID(int boyID){
		this.boyID = boyID;
		return true;
	}
	
	public Manager getManager(){
		return manager;
	}
	
	public boolean setManager(Manager manager){
		this.manager = manager;
		return true;
	}

	public ArrayList<Parking> getRegParckingList(){
		return regParkingsList;
	}
	
	public boolean regParcking(Parking parcking){
		regParkingsList.add(parcking);
		return true;
	}
	
	public ArrayList<Car> getCarList(){
		return carList;
	}
	
	public boolean addCar(Car car){
		return carList.add(car);
	}
	
	public boolean removeCar(Car car){
		return carList.remove(car);
	}
	
	public boolean helpPark(Car car){
		return true;
	}
}
