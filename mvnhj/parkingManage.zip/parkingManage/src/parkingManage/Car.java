package parkingManage;

public class Car {
	private String carID = "";
	
	public String getCarId(){
		return carID;
	}
	
	public boolean setCarID(String carID){
		this.carID = carID;
		return true;
	}
	
	public Car(String carID){
		this.carID = carID;
	}
}
