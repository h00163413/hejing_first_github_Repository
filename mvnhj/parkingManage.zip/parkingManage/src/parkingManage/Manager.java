package parkingManage;

import java.util.ArrayList;

public class Manager {
	private int managerID = 0;
	private int selectedBoyIndex = -1;
	private ArrayList<ParkingBoy> BoyList=new ArrayList<ParkingBoy>();
	private ArrayList<Parking> familiarParking = new ArrayList<Parking>();
	static private ArrayList<Manager> managerList=new ArrayList<Manager>(); 
	
	public int getManagerID(){
		return managerID;
	}
	
	public boolean setManagerID(int managerID){
		this.managerID = managerID;
		return true;
	}
	
	public boolean addBoy(ParkingBoy boy){
		boy.setManager(this);
		return BoyList.add(boy);
	}
	
	public boolean removeboy(ParkingBoy boy){
		return BoyList.remove(boy);
	}
	
	public ArrayList<Parking> getFamiliarParcking(){
		return familiarParking;
	}
	
	public boolean addFamiliarParking(Parking parking){
		return familiarParking.add(parking);
	}
	
	public boolean removeFamiliarParcking(Parking parking){
		return familiarParking.remove(parking);
	}
	
	public boolean helpPark(Car car){
		if(selectedBoyIndex >= BoyList.size()){
			selectedBoyIndex = 0;
		}
		else{
			selectedBoyIndex++;
		}
		
		ParkingBoy boy = BoyList.get(selectedBoyIndex);
		return boy.helpPark(car);
	}
	static public ArrayList<Manager> getManagerList(){
		return managerList;
	}
	
}
