package parkingManage;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("system start!");
		
		
		Manager manager = new Manager();
		ParkingBoy boy = new ParkingBoy();
		manager.addBoy(boy);
		
		Main mainClass = new Main();
		mainClass.CarIn(new Car("0000"), manager);
	}
	
	public boolean CarIn(Car car, Manager manager){
		return manager.helpPark(car);
	}

}
